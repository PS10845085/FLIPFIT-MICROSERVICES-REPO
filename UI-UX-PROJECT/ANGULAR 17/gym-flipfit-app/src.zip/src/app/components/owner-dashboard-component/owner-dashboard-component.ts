import { Component } from '@angular/core';

@Component({
  selector: 'app-owner-dashboard-component',
  standalone: false,
  templateUrl: './owner-dashboard-component.html',
  styleUrl: './owner-dashboard-component.css',
})
export class OwnerDashboardComponent {

}
