
// src/app/app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/dashboard-component/dashboard-component';
import { LoginComponent } from './components/login-component/login-component';
import { authGuard } from './guards/auth.guard';  
import { guestGuard } from './guards/guest.guard';

import { roleGuard } from './guards/role.guard';


import { RegisterComponent } from './components/register-component/register-component';

import { OwnerDashboardComponent } from './components/owner-dashboard-component/owner-dashboard-component';
import { AdminDashboardComponent } from './components/admin-dashboard-component/admin-dashboard-component';
import { CustomerDashboardComponent } from './components/customer-dashboard-component/customer-dashboard-component';


const routes: Routes = [
  // Public route
  { path: 'login', component: LoginComponent,  canActivate: [guestGuard]},

  { path: 'register', component: RegisterComponent, canActivate: [guestGuard] }, 


  
{ 
    path: 'dashboard-owner', 
    component: OwnerDashboardComponent, 
    canActivate: [authGuard, roleGuard],
    data: { roles: [1] } // 1 = OWNER
  },
  { 
    path: 'dashboard-admin', 
    component: AdminDashboardComponent, 
    canActivate: [authGuard, roleGuard],
    data: { roles: [2] } // 2 = ADMIN
  },
  { 
    path: 'dashboard-customer', 
    component: CustomerDashboardComponent, 
    canActivate: [authGuard, roleGuard],
    data: { roles: [3] } // 3 = CUSTOMER
  },

  // Protected route
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },

  // Default: go to login
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // Wildcard: go to login
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    // For Angular Universal (SSR), you can enable:
    // initialNavigation: 'enabledBlocking'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
